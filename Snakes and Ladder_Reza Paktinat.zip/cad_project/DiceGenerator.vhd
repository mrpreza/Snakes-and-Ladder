
entity DiceGenerator is
    Port(
        clk         : in  std_logic;
        reset       : in  std_logic;
        roll_dice   : in  std_logic;
        dice_value  : out integer range 1 to 6
    );
end DiceGenerator;

architecture Behavioral of DiceGenerator is
    signal lfsr : std_logic_vector(31 downto 0) := (others => '1');
begin
    process(clk, reset)
    begin
        if reset = '1' then
            lfsr <= (others => '1');
        elsif rising_edge(clk) then
            if roll_dice = '1' then
                lfsr <= lfsr32(lfsr);
                dice_value <= to_integer(unsigned(lfsr(2 downto 0))) mod 6 + 1;
            end if;
        end if;
    end process;
   
    -- LFSR function as provided in the image
    function lfsr32(x : std_logic_vector(31 downto 0)) return std_logic_vector is
    begin
        return x(30 downto 0) & (x(0) xnor x(1) xnor x(21) xnor x(31));
    end function;
end Behaviora