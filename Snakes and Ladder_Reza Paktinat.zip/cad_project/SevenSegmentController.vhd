entity SevenSegmentController is
    Port (
        clk : in std_logic;
        reset : in std_logic;
        display_value : in integer range 0 to 9999;
        game_over : in std_logic;
        winner : in std_logic;
        outseg : out std_logic_vector(3 downto 0);
        sevensegments : out std_logic_vector(7 downto 0)
    );
end SevenSegmentController;

architecture Behavioral of SevenSegmentController is
    signal digit_select : integer range 0 to 3 := 0;
    signal current_digit : integer range 0 to 9 := 0;
   
    function to_seven_segment(digit : integer) return std_logic_vector is
    begin
        case digit is
            when 0 => return "11000000";
            when 1 => return "11111001";
            when 2 => return "10100100";
            when 3 => return "10110000";
            when 4 => return "10011001";
            when 5 => return "10010010";
            when 6 => return "10000010";
            when 7 => return "11111000";
            when 8 => return "10000000";
            when 9 => return "10010000";
            when others => return "11111111";
        end case;
    end function;
   
begin
    process(clk, reset)
        variable counter : integer range 0 to 100000 := 0;
    begin
        if reset = '1' then
            digit_select <= 0;
            counter := 0;
        elsif rising_edge(clk) then
            counter := counter + 1;
            if counter = 100000 then
                counter := 0;
                digit_select <= (digit_select + 1) mod 4;
            end if;
        end if;
    end process;
   
    process(clk)
    begin
        if rising_edge(clk) then
            if game_over = '1' then
                case digit_select is
                    when 0 => current_digit <= 5; -- S
                    when 1 => current_digit <= 0; -- U
                    when 2 => current_digit <= 6; -- C
                    when 3 => current_digit <= 6; -- C
                end case;
            else
                case digit_select is
                    when 0 => current_digit <= display_value mod 10;
                    when 1 => current_digit <= (display_value / 10) mod 10;
                    when 2 => current_digit <= (display_value / 100) mod 10;
                    when 3 => current_digit <= display_value / 1000;
                end case;
            end if;
        end if;
    end process;
   
    outseg <= "1110" when digit_select = 0 else
              "1101" when digit_select = 1 else
              "1011" when digit_select = 2 else
              "0111";
   
    sevensegments <= to_seven_segment(current_digit);
end Behavioral;
	
