library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity CAD971Test is
Port(
    -- CLOCK
    CLOCK_24 : in std_logic;
    -- RESET
    RESET_N : in std_logic;
    -- VGA
    VGA_B : out std_logic_vector(1 downto 0);
    VGA_G : out std_logic_vector(1 downto 0);
    VGA_HS : out std_logic;
    VGA_R : out std_logic_vector(1 downto 0);
    VGA_VS : out std_logic;
    -- KEYS
    Key : in std_logic_vector(3 downto 0);
    SW : in std_logic_vector(7 downto 0);
    -- LEDS
    Leds : out std_logic_vector(7 downto 0);
    -- Segments
    outseg : out bit_vector(3 downto 0);
    sevensegments : out bit_vector(7 downto 0)
);
end CAD971Test;

architecture Behavioral of CAD971Test is
    signal ScanlineX, ScanlineY : std_logic_vector(10 downto 0);
    signal ColorTable : std_logic_vector(5 downto 0);
    signal seg0, seg1, seg2, seg3 : bit_vector(7 downto 0) := x"c0";
    signal seg_selectors : bit_vector(3 downto 0) := "1110";
    signal output : bit_vector(7 downto 0) := x"c0";
    signal input : integer range 0 to 100 := 0;
    signal timer_game : integer range 0 to 100 := 0;
    signal end_game : bit := '0';
    signal score : integer := 0;
    signal lose : bit := '0';
    signal leds_signal : std_logic_vector(7 downto 0) := "10101010";

begin
    -- Placeholder for VGA_controller
    process(CLOCK_24)
    begin
        if rising_edge(CLOCK_24) then
            VGA_HS <= '0';
            VGA_VS <= '0';
            VGA_R <= "00";
            VGA_G <= "00";
            VGA_B <= "00";
            ScanlineX <= (others => '0');
            ScanlineY <= (others => '0');
        end if;
    end process;

    -- Placeholder for VGA_Square
    process(CLOCK_24)
    begin
        if rising_edge(CLOCK_24) then
            ColorTable <= (others => '0');
            score <= 0;
            lose <= '0';
        end if;
    end process;

    -- Seven segment display process
    process(CLOCK_24)
        variable counter : integer range 0 to 5000 := 0;
    begin
        if rising_edge(CLOCK_24) then
            counter := counter + 1;
            if counter = 4999 then
                counter := 0;
                seg_selectors <= seg_selectors(0) & seg_selectors(3 downto 1);
            end if;
        end if;
    end process;

    -- Timer of game
    process(CLOCK_24, RESET_N)
        variable flag_key : bit := '0';
        variable flag_rst : bit := '0';
        variable counter : integer range 0 to 24000000 := 0;
    begin
        if RESET_N = '0' then
            flag_key := '0';
            flag_rst := '1';
            counter := 0;
            timer_game <= 0;
        elsif rising_edge(CLOCK_24) then
            if key(0) = '0' and flag_rst = '1' then
                flag_key := '1';
            end if;
            if flag_key = '1' then
                counter := counter + 1;
                if counter = 23999999 then
                    counter := 0;
                    if end_game = '1' then
                        timer_game <= timer_game;
                    else
                        timer_game <= timer_game + 1;
                    end if;
                end if;
            end if;
        end if;
    end process;

    -- Detect game end
    process(timer_game)
    begin
        if score = 10 or timer_game = 99 or lose = '1' then
            end_game <= '1';
        else
            end_game <= '0';
        end if;
    end process;

    -- Handle LEDs
    process(RESET_N, CLOCK_24)
        variable flag_rst : bit := '0';
        variable timer_leds : integer range 0 to 12000001 := 0;
    begin
        if RESET_N = '0' then
            flag_rst := '1';
            Leds <= "00000000";
            leds_signal <= "10101010";
            timer_leds := 0;
        elsif rising_edge(CLOCK_24) then
            timer_leds := timer_leds + 1;
            if flag_rst = '1' and end_game = '1' then
                Leds <= "11111111";
            elsif flag_rst = '1' and end_game = '0' and timer_leds = 12000000 then
                leds_signal <= leds_signal(0) & leds_signal(7 downto 1);
                Leds <= leds_signal;
            end if;
        end if;
    end process;

    -- Output segment selectors
    outseg <= seg_selectors;

    -- Display segments
    process(seg_selectors, seg0, seg1, seg2, seg3)
    begin
        case seg_selectors is
            when "1110" => sevensegments <= seg0;
            when "0111" => sevensegments <= seg3;
            when "1011" => sevensegments <= seg2;
            when "1101" => sevensegments <= seg1;
            when others => sevensegments <= x"c0";
        end case;
    end process;

    -- Update segments based on score and timer
    process(RESET_N, CLOCK_24)
        variable flag_key : bit := '0';
    begin
        if RESET_N = '0' then
            seg0 <= x"a4";
            seg1 <= x"a4";
            seg2 <= x"f9";
            seg3 <= x"98";
            flag_key := '0';
        elsif rising_edge(CLOCK_24) then
            if key(0) = '0' then
                flag_key := '1';
            end if;
            if flag_key = '1' and end_game = '0' then
                case score is
                    when 0 => seg3 <= x"c0"; seg2 <= x"c0";
                    when 1 => seg3 <= x"f9"; seg2 <= x"c0";
                    when 2 => seg3 <= x"a4"; seg2 <= x"c0";
                    when 3 => seg3 <= x"b0"; seg2 <= x"c0";
                    when 4 => seg3 <= x"99"; seg2 <= x"c0";
                    when 5 => seg3 <= x"92"; seg2 <= x"c0";
                    when 6 => seg3 <= x"82"; seg2 <= x"c0";
                    when 7 => seg3 <= x"f8"; seg2 <= x"c0";
                    when 8 => seg3 <= x"80"; seg2 <= x"c0";
                    when 9 => seg3 <= x"98"; seg2 <= x"c0";
                    when 10 => seg3 <= x"c0"; seg2 <= x"f9";
                    when others => seg3 <= x"c0"; seg2 <= x"c0";
                end case;

                if timer_game >= 90 then
                    input <= timer_game - 90;
                    seg1 <= output;
                    seg0 <= x"98";
                elsif timer_game >= 80 then
                    input <= timer_game - 80;
                    seg1 <= output;
                    seg0 <= x"80";
                elsif timer_game >= 70 then
                    input <= timer_game - 70;
                    seg1 <= output;
                    seg0 <= x"f8";
                elsif timer_game >= 60 then
                    input <= timer_game - 60;
                    seg1 <= output;
                    seg0 <= x"82";
                elsif timer_game >= 50 then
                    input <= timer_game - 50;
                    seg1 <= output;
                    seg0 <= x"92";
                elsif timer_game >= 40 then
                    input <= timer_game - 40;
                    seg1 <= output;
                    seg0 <= x"99";
                elsif timer_game >= 30 then
                    input <= timer_game - 30;
                    seg1 <= output;
                    seg0 <= x"b0";
                elsif timer_game >= 20 then
                    input <= timer_game - 20;
                    seg1 <= output;
                    seg0 <= x"a4";
                elsif timer_game >= 10 then
                    input <= timer_game - 10;
                    seg1 <= output;
                    seg0 <= x"f9";
                else
                    input <= timer_game;
                    seg1 <= output;
                    seg0 <= x"c0";
                end if;
            end if;
        end if;
    end process;

    -- Seven segment decoder
    process(input)
    begin
        case input is
            when 0 => output <= x"c0";
            when 1 => output <= x"f9";
            when 2 => output <= x"a4";
            when 3 => output <= x"b0";
            when 4 => output <= x"99";
            when 5 => output <= x"92";
            when 6 => output <= x"82";
            when 7 => output <= x"f8";
            when 8 => output <= x"80";
            when 9 => output <= x"98";
            when others => output <= x"c0";
        end case;
    end process;

end Behavioral;