entity GameBoardGenerator is
    Port(
        clk         : in  std_logic;
        reset       : in  std_logic;
        ScanlineX   : in  std_logic_vector(10 downto 0);
        ScanlineY   : in  std_logic_vector(10 downto 0);
        ColorOut    : out std_logic_vector(5 downto 0)
    );
end GameBoardGenerator;

architecture Behavioral of GameBoardGenerator is
    -- Constants for board size and colors
    constant BOARD_WIDTH  : integer := 15;
    constant BOARD_HEIGHT : integer := 10;
    constant SQUARE_SIZE  : integer := 40;
   
    -- Signals for dynamic color changing
    signal color_counter : integer range 0 to 255 := 0;
    signal board_colors  : array (0 to BOARD_WIDTH*BOARD_HEIGHT-1) of std_logic_vector(5 downto 0);
begin
    process(clk)
    begin
        if rising_edge(clk) then
            -- Update colors dynamically
            if color_counter = 255 then
                color_counter <= 0;
                -- Update board_colors array with new random colors
            else
                color_counter <= color_counter + 1;
            end if;
           
            -- Generate checkered board
            if (ScanlineX / SQUARE_SIZE + ScanlineY / SQUARE_SIZE) mod 2 = 0 then
                ColorOut <= board_colors((ScanlineY / SQUARE_SIZE) * BOARD_WIDTH + (ScanlineX / SQUARE_SIZE));
            else
                ColorOut <= "111111"; -- White for alternate squares
            end if;
        end if;
    end process;
end Behavioral;