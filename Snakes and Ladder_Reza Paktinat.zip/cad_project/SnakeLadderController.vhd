entity SnakeLadderController is
    Port (
        clk : in std_logic;
        reset : in std_logic;
        player_pos : in integer range 1 to 150;
        new_pos : out integer range 1 to 150
    );
end SnakeLadderController;

architecture Behavioral of SnakeLadderController is
    type snake_ladder_array is array (1 to 10) of integer range 1 to 150;
    constant snakes : snake_ladder_array := (14, 19, 48, 72, 88, 95, 99, 47, 36, 6);
    constant ladders : snake_ladder_array := (4, 9, 28, 40, 51, 63, 71, 80, 95, 148);
begin
    process(clk, reset)
    begin
        if reset = '1' then
            new_pos <= 1;
        elsif rising_edge(clk) then
            new_pos <= player_pos;
           
            -- Check for snakes
            for i in 1 to 5 loop
                if player_pos = snakes(2*i-1) then
                    new_pos <= snakes(2*i);
                end if;
            end loop;
           
            -- Check for ladders
            for i in 1 to 5 loop
                if player_pos = ladders(2*i-1) then
                    new_pos <= ladders(2*i);
                end if;
            end loop;
        end if;
    end process;
end Behavioral;
-- Add these signals to the entity
update_positions : in std_logic;
random_seed : in std_logic_vector(31 downto 0);

-- Add this process to the architecture
process(clk)
    variable rand_index : integer range 1 to 10;
begin
    if rising_edge(clk) then
        if update_positions = '1' then
            rand_index := to_integer(unsigned(random_seed(3 downto 0))) mod 10 + 1;
            snakes(rand_index) <= to_integer(unsigned(random_seed(10 downto 4))) mod 150 + 1;
           
            rand_index := to_integer(unsigned(random_seed(14 downto 11))) mod 10 + 1;
            ladders(rand_index) <= to_integer(unsigned(random_seed(21 downto 15))) mod 150 + 1;
        end if;
    end if;
end process;