entity PlayerMovementController is
    Port(
        clk         : in  std_logic;
        reset       : in  std_logic;
        dice_value  : in  integer range 1 to 6;
        move_player : in  std_logic;
        player_pos  : out integer range 1 to 150
    );
end PlayerMovementController;

architecture Behavioral of PlayerMovementController is
    signal current_pos : integer range 1 to 150 := 1;
begin
    process(clk, reset)
    begin
        if reset = '1' then
            current_pos <= 1;
        elsif rising_edge(clk) then
            if move_player = '1' then
                if current_pos + dice_value <= 150 then
                    current_pos <= current_pos + dice_value;
                end if;
            end if;
        end if;
    end process;
   
    player_pos <= current_pos;
end Behavioral;