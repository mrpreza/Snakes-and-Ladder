entity GameStateController is
    Port (
        clk : in std_logic;
        reset : in std_logic;
        roll_dice : in std_logic;
        player1_pos : in integer range 1 to 150;
        player2_pos : in integer range 1 to 150;
        current_player : out std_logic;
        game_over : out std_logic;
        winner : out std_logic
    );
end GameStateController;

architecture Behavioral of GameStateController is
    type game_state_type is (PLAYER1_TURN, PLAYER2_TURN, GAME_OVER);
    signal game_state : game_state_type := PLAYER1_TURN;
begin
    process(clk, reset)
    begin
        if reset = '1' then
            game_state <= PLAYER1_TURN;
            current_player <= '0';
            game_over <= '0';
            winner <= '0';
        elsif rising_edge(clk) then
            case game_state is
                when PLAYER1_TURN =>
                    current_player <= '0';
                    if roll_dice = '1' then
                        game_state <= PLAYER2_TURN;
                    end if;
                    if player1_pos = 150 then
                        game_state <= GAME_OVER;
                        game_over <= '1';
                        winner <= '0';
                    end if;
               
                when PLAYER2_TURN =>
                    current_player <= '1';
                    if roll_dice = '1' then
                        game_state <= PLAYER1_TURN;
                    end if;
                    if player2_pos = 150 then
                        game_state <= GAME_OVER;
                        game_over <= '1';
                        winner <= '1';
                    end if;
               
                when GAME_OVER =>
                    game_over <= '1';
            end case;
        end if;
    end process;
end Behavioral;